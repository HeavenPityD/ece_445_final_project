# Lab Notebook

Richard Deng (ruichao4)

# September 7th - Subsystem Design

We discussed our project with TA and talked about how our project will be consisting of three subsystems

# September 13th - Network chip selection

We decided to use ESP8266 as our networking chip to communicate between our FPGA trading strategy and simulated exchange

# September 24th - Power Supply Design

We chose to use 3.3V power on the FPGA pin to power the whole system

  
# October 4th - Simulated Exchange Design

I designed simulated exchange and coded it using C++. I also shared my design with my teammates.

![](block_diagram.png)

# October 10th - PCB design change

We discussed about processing network on PCB would be too hard, so we decided to do this on FPGA instead. I also designed the block diagram of two LEDs to display our balance on KiCad.

# October 18th - PCB design review

We talked with professor about our PCB design and we decided to add another two-line display to our PCB. 

![](msg_board.jpg)

![](sch.png)

# October 24th - Parts Selection

We have submitted the PCB design and decided our parts. The FPGA board will be an Artix-7 FPGA board, and a seven segment segment decoder (74LS248), binary counters (74LS590), and message boards (NHD-C0220BIZ).

![](final_sch.png)

![](pcb.png)

# October 31th - Decide to use breadboard partially

After examine the parts we found out that a few of them don't fit on PCB, so we decided to move those parts and wire them on breadboard. I wired them and connected them on breadboard.

# November 7th - Soldering

I and kevin went to the lab and soldered the parts that fits on PCB. After going home I wired the rest of our design on breadboard and connect them with PCB. I also tried to interface the two-line display using I2C protocol and control signals via FPGA, but didn't successfully light the display.

# November 8th - Building

We were trying to put everything together and connect different subsystems. I also wrote our trading strategy on FPGA beforehand and improved it and trying to connect it with different parts.

# November 16th - Mock Demo

We demoed our exchange and FPGA trading strategy to TA.

# November 18th - LED Testing

I wrote the LED driver code on FPGA and tested it with Siyi. 

![](led_driver.png)


# November 24th - Arduino

After I tried to control SDA and SCL signals using FPGA to control the two line display via I2C protocol, I found that the display is still not working. It seems like there is complicated timing issue and using FPGA to time the serial signals can be hard. I also found out that the two-line display is actually for Arduino and they have setup code using Arduino, and therefore I and Siyi went to ECE supply center and bought an Arduino. I wrote the driver code on Arduino connected it to our system.

# November 29th - Final Product

We finalized our design and shared design with teammates. We also tested the subsystems and made sure it is working before final demo.

![](product.jpg)

![](waiting.jpg)

![](order_sent.jpg)