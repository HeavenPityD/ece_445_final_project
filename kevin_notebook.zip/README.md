# Lab Notebook

Kevin Lim (wzlim2)

# September 7th - First Meeting

I have joined the group and am currently learning and understanding the project. We will have a meeting soon that walks through the project and discusses what to do in the next few weeks.

# September 13th - UDP Chip

We are discussing the inclusion of the UDP chip in our design. In our current design, the UDP chip will serve as the network communication protocol between the simulated  exchange and the FPGA board, and will be installed on the PCB.

# September 24th - Power Supply Design

We are discussing the power supply in the design. The ESP8266 requires a 3.3V power supply and 170mA maximum current. This will be connected to the PCB. The Design Document Check is on Tuesday so we are working on getting the doucment done.

# September 27th - Design Document Check

Siyi and I attended the document check. Some notes:
- Add more details to the introduction section.
- Add more details for the block diagram. Include power supply and color different subsystems.
- Explain how we are going to test the project -- include verification tables for each subsystem and quantify the testing methods.
- For the cost section, include the cost for FPGA, PCB, components on PCB (such as UDP).
- Add references.

# September 29th - Block Diagram Update

We have submitted the design document. We added details to the document, including updating the block diagram and visualization.
- Current visualization:

![](user_diagram.png)
  
# October 4th - Simulated Exchange Design

Richard has drafted a first version of the simulated exchange. We will help him finish the rest of the code for the simulated exchange, including bug fixes to the orderbook and other files. We have also updated the block diagram to include everything we have in our design, including the power supply.

![](block_diagram.png)

# October 10th - PCB design

In this discussion, we think that the UDP network design may be too complicated. We are thinking about solutions and replacements. Since our design is not complete, we probably will not submit a PCB order by the deadline.

# October 18th - PCB design discussion with Professors

In the discussion we decided to include two 4-digit LEDs which will display the balance. We will also include a message board to show trade status.
Some notes:
- First part:  Hardware, Finite state machine, FPGA (we are mostly finished with this part)
- Second part: making trading decisions, communication with PCB/LED display
- Third part: grabbing data via internet (exchange)

![](msg_board.jpg)

![](sch.png)

# October 24th - Parts Selection

We have submitted the PCB design and are buying components for the PCB board. The FPGA board we will buy is the Artix-7 FPGA board. We will also get LEDs, a segment segment decoder (74LS248), binary counters (74LS590), and message boards (NHD-C0220BIZ).

![](final_sch.png)

![](pcb.png)

# October 31th - Parts Arrived

The PCB and the components have arrived, which means that we can start building. We found out that a few components didn't fit the PCB board. After some discussion, we decided to put them on a breadboard for now.

# November 7th - Smoldering

We have smoldered parts to the PCB.  We succesfully smoldered the components that fit on the PCB. As planned, the parts that didn't fit on the PCB are on the breadboard.

# November 8th - Building

We are building the system, connecting the PCB with smoldered parts with the FPGA board and the simulated exchange. For the components that didn't fit the PCB, we have put them on the breadboard for now. After building is done, we can test the system.

# November 16th - Mock Demo

We did not demo PCB board. TA advises us to focus on making the subsystems work.

# November 18th - LED Testing

We have tested the LED driver on Vivado.

![](led_driver.png)

Most of the project is done, including the simulated exchange, FPGA Trading strategy, and the PCB. We still need to program the message board on FPGA.

# November 24th - Arduino

We found out it was quite difficult to implement the message board driver with FPGA. We decided to use an Arduino board instead. At some point in the past week we burned the message board on the PCB, so we needed to connect a new one to the system via breadboard.

# November 29th - Final Product

We are finalizing what we want to show in the final demo. The proudct includes the PCB, a breadboard with components that didn't fit in the PCB (including the 2 4-digit LEDs that displays the balance), an FPGA board, an Arduino board, and the message board. All of these will be connected to the simulated exchange on a computer when we do the demo.

![](product.jpg)

![](waiting.jpg)

![](order_sent.jpg)